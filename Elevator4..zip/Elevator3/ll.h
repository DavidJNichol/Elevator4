#ifndef LL_H
#define LL_H
#endif


struct Node{
	int data;
	struct Node *next;
};

void append(struct Node **head, int new_data);

void print_list(struct Node *n);


void clear_list(struct Node** n);

